CREATE TABLE `person_count_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `location_id` int DEFAULT NULL,
  `person_count` int DEFAULT NULL,
  `max_person_count` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=360103 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
