CREATE TABLE `water_temperatures` (
  `category_id` int NOT NULL,
  `measurement_site` varchar(255) DEFAULT NULL,
  `body_of_water` varchar(255) NOT NULL,
  `date` timestamp NOT NULL,
  `water_temperature` float NOT NULL,
  UNIQUE KEY `unique_body_of_water_date` (`body_of_water`,`date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
